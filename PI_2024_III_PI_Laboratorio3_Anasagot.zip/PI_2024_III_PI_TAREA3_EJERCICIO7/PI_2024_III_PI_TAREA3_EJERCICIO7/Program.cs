﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI_2024_III_PI_TAREA3_EJERCICIO7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {

                Console.WriteLine("Ingresa el nombre del empleado: ");
                string nombre = Console.ReadLine();

                Console.WriteLine("Ingresa la edad del empleado: ");
                int edad = int.Parse(Console.ReadLine()); 

                Console.Write("Ingresa el salario del empleado: ");
                double salario = double.Parse(Console.ReadLine()); 

                Console.WriteLine("Ingresa el departamento del empleado: ");
                string departamento = Console.ReadLine();

                Console.WriteLine("Datos del empleado: ");
                Console.WriteLine($"Nombre: {nombre} ");
                Console.WriteLine($"Edad: {edad} ");
                Console.WriteLine($"Salario: {salario} ");
                Console.WriteLine($"Departamento: {departamento} ");
            }
            catch (FormatException ex)
            {
 
                Console.WriteLine("Error: Debes ingresar un valor numerico valido para la edad o salario. ");
                Console.WriteLine($"Detalles del error: {ex.Message}");
            }
            catch (Exception ex)
            {
 
                Console.WriteLine("Se produjo un error inesperado.");
                Console.WriteLine($"Detalles del error: {ex.Message} ");
            }
            finally
            {
 
                Console.WriteLine("Proceso finalizado. ");
            }
        }
    }
}
