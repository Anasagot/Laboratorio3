﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI_2024_III_PI_TAREA3_EJERCICIO4
{
    internal class Program
    {
        static void Main()
        {
           
            IngresarDepartamentos();
        }

        static void IngresarDepartamentos()
        {
            Console.WriteLine("¿Cuantos departamentos tiene la empresa? ");
            int cantidadDepartamentos;

            if (int.TryParse(Console.ReadLine(), out cantidadDepartamentos) && cantidadDepartamentos > 0)
            {
                string[] departamentos = new string[cantidadDepartamentos];

                for (int i = 0; i < cantidadDepartamentos; i++)
                {
                    Console.Write($"Ingresa el nombre del departamento {i + 1}: ");
                    departamentos[i] = Console.ReadLine(); 
                }
                Console.WriteLine("Los departamentos ingresados son:");
                foreach (string departamento in departamentos)
                {
                    Console.WriteLine("- " + departamento);
                }
            }
            else
            {
                Console.WriteLine("Entrada no valida. Debes ingresar un numero entero positivo. ");
            }
        }
        
    }
}
    

