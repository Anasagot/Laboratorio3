﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI_2024_III_PI_TAREA3_EJERCICIO6
{
    internal class Program
    {
        static void Main(string[] args)
        {

            List<Empleado> empleados = new List<Empleado>();

            Console.WriteLine("¿Cuántos empleados deseas ingresar?: ");
            int cantidadEmpleados = int.Parse(Console.ReadLine());

            for (int i = 0; i < cantidadEmpleados; i++)
            {
                Console.WriteLine($"\nEmpleado {i + 1} ");

                Console.Write("Nombre: ");
                string nombre = Console.ReadLine();

                Console.Write("Edad: ");
                int edad = int.Parse(Console.ReadLine());

                Console.Write("Salario mensual (Lps): ");
                double salarioMensual = double.Parse(Console.ReadLine());

                empleados.Add(new Empleado(nombre, edad, salarioMensual));
            }

            empleados.ForEach(empleado =>
            {
                empleado.CalcularSalarioAnual();
                Console.WriteLine($"Empleado: {empleado.Nombre} ");
                Console.WriteLine($"Edad: {empleado.Edad} ");
                Console.WriteLine($"Salario mensual: {empleado.SalarioMensual} ");
                Console.WriteLine($"Salario anual: {empleado.SalarioAnual} ");
            });
        }
    }

    class Empleado
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
        public double SalarioMensual { get; set; }
        public double SalarioAnual { get; private set; }

        public Empleado(string nombre, int edad, double salarioMensual)
        {
            Nombre = nombre;
            Edad = edad;
            SalarioMensual = salarioMensual;
        }

        public void CalcularSalarioAnual()
        {
            Func<double, double> calcularAnual = salarioMensual => salarioMensual * 12;
            SalarioAnual = calcularAnual(SalarioMensual);
        }
    }
}

