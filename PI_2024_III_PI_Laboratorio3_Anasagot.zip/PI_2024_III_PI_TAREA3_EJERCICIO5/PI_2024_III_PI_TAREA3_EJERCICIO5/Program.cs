﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI_2024_III_PI_TAREA3_EJERCICIO5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Ingrese el número de empleados: ");
            int numEmpleados;

            if (int.TryParse(Console.ReadLine(), out numEmpleados) && numEmpleados > 0)
            {

                string[,] empleados = new string[numEmpleados, 3];

                for (int i = 0; i < numEmpleados; i++)
                {
                    Console.WriteLine($"\nIngresando datos para el empleado #{i + 1}:");

                    Console.WriteLine("Nombre del empleado: ");
                    empleados[i, 0] = Console.ReadLine();

                    Console.Write("Puesto del empleado: ");
                    empleados[i, 1] = Console.ReadLine();

                    Console.Write("Salario del empleado: ");
                    string salario = Console.ReadLine();
                    empleados[i, 2] = salario;
                }

                Console.WriteLine("Datos de los empleados:");
                Console.WriteLine("------------------------------------------------");
                Console.WriteLine("Nombre Puesto Salario");
                Console.WriteLine("------------------------------------------------");

                for (int i = 0; i < numEmpleados; i++)
                {
                    Console.WriteLine($"{empleados[i, 0]} {empleados[i, 1]} {empleados[i, 2]}");

                }
                Console.ReadLine();
            }

        }
    }
 
}