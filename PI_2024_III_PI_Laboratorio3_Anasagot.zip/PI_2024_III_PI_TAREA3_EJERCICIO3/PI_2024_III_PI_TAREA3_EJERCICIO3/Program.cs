﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI_2024_III_PI_TAREA3_EJERCICIO3
{
    internal class Program
    {
        static void Main()
        {
            double salarioDiario;

            Console.Write("Ingresa el salario base por día del empleado: ");

            if (double.TryParse(Console.ReadLine(), out salarioDiario) && salarioDiario > 0)
            {

                double salarioMensual = CalcularSalarioMensual(salarioDiario);
                double salarioAnual = CalcularSalarioAnual(salarioMensual);

                
                Console.WriteLine($"El salario mensual del empleado es: {salarioMensual} ");
                Console.WriteLine($"El salario anual del empleado es: {salarioAnual} ");
            }
            else
            {
               
                Console.WriteLine("Entrada no válida. Debes ingresar un número positivo para el salario: ");
            }
        }

        static double CalcularSalarioMensual(double salarioDiario)
        {
            int diasLaboralesPorMes = 22; 
            return salarioDiario * diasLaboralesPorMes;
        }

        static double CalcularSalarioAnual(double salarioMensual)
        {
            return salarioMensual * 12; 
            Console.ReadLine();
        }
    }
}
