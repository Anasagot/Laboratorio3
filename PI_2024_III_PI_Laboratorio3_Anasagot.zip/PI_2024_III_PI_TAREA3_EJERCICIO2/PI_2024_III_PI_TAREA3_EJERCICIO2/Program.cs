﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI_2024_III_PI_TAREA3_EJERCICIO2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool continuaragregando = true;

            while (continuaragregando)
            {
                try
                {
                    Console.Write("Ingresa el nombre del empleado: ");
                    string nombre = Console.ReadLine();

                    Console.Write("Ingresa la edad del empleado: ");
                    int age = Convert.ToInt32(Console.ReadLine());

                    if (age < 18 || age > 65)
                    {
                        Console.WriteLine("Edad no valida. Debe estar entre 18 y 65 años. ");
                    }
                    else
                    {
                        Console.WriteLine($"Empleado {nombre}, Edad {age}, registrado correctamente. ");
                    }

                    Console.Write("¿Deseas agregar otro empleado? (si/no): ");

                    continuaragregando = Console.ReadLine().ToLower() == "si";
                }
                catch (FormatException)
                {
                    Console.WriteLine("Error: La edad debe ser un número válido. ");
                }
                Console.ReadLine();
            }
        }
    }
}
