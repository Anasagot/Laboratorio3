﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI_2024_III_PI_T3_EJERCICIO1
{
    internal class Program
    {
        static void Main()
        {

            Console.WriteLine("Ingresa el rango del empleado (menor, medio, superior): ");
            string rango = Console.ReadLine().ToLower();

            double salario;

            if (rango == "menor")
            {
                salario = 15000;
            }
            else if (rango == "medio")
            {
                salario = 25000;
            }
            else if (rango == "superior")
            {
                salario = 40000;
            }
            else
            {
                Console.WriteLine("Rango no válido. Debes ingresar menor, medio o superior ");
                return;

                Console.WriteLine($"El salario del empleado con rango {rango} es: {salario} Lps.");
            }
            Console.ReadLine(); 

        }
    }
}