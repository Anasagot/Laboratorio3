﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI_2024_III_PI_TAREA3_EJERCICIO8
{
    internal class Program
    {
        static void Main()
        {
            //Menu consola.
            static string[] nombres = new string[5];
            static int   [] edades = new int[5];
            static double[] salarios = new double[5];
            static string[] departamentos = new string[5];
            static string[] rangos = new string[5];
            static string[] fechasIngreso = new string[5];
            static string[] puestos = new string[5];

            static void Main()
            {
                bool salir = false;

                while (salir)
                {
                    Console.Clear();
                    Console.WriteLine("=== Menú de Opciones === ");
                    Console.WriteLine("1. Agregar información de empleados ");
                    Console.WriteLine("2. Visualizar información de todos los empleados ");
                    Console.WriteLine("3. Imprimir información de un empleado específico ");
                    Console.WriteLine("4. Calcular salario mensual y anual de un empleado ");
                    Console.WriteLine("5. Salir ");
                    Console.WriteLine("Seleccione una opción: ");

                    string opcion = Console.ReadLine();

                    switch (opcion)
                    {
                        case "1":
                            AgregarArreglo();
                            break;
                        case "2":
                            VisualizarArreglo();
                            break;
                        case "3":
                            ImprimirPosicionArreglo();
                            break;
                        case "4":
                            CalcularSalario();
                            break;
                        case "5":
                            salir = true;
                            Console.WriteLine("Saliendo del programa...");
                            break;
                        default:
                            Console.WriteLine("Opción no valida.");
                            break;
                    }

                    Console.WriteLine("Presiona Enter para continuar...");
                    Console.ReadLine();
                }
            }

             void AgregarArreglo()
            {
                Console.Clear();
                Console.WriteLine("== Agregar información de empleados ==");

                for (int i = 0; i < nombres.Length; i++)
                {
                    Console.Write($"Ingrese el nombre del empleado {i + 1}: ");
                    nombres[i] = Console.ReadLine();

                    Console.Write($"Ingrese la edad del empleado {i + 1}: ");
                    while (!int.TryParse(Console.ReadLine(), out edades[i]) || edades[i] <= 0)
                    {
                        Console.WriteLine("Entrada inválida. Por favor, ingrese un número positivo.");
                    }

                    Console.Write($"Ingrese el salario del empleado {i + 1}: ");
                    while (!double.TryParse(Console.ReadLine(), out salarios[i]) || salarios[i] <= 0)
                    {
                        Console.WriteLine("Entrada inválida. Por favor, ingrese un salario positivo.");
                    }

                    Console.Write($"Ingrese el departamento del empleado {i + 1}: ");
                    departamentos[i] = Console.ReadLine();

                    Console.Write($"Ingrese el rango del empleado (menor, medio, superior) {i + 1}: ");
                    rangos[i] = Console.ReadLine();

                    Console.Write($"Ingrese la fecha de ingreso del empleado {i + 1} (dd/mm/yyyy): ");
                    fechasIngreso[i] = Console.ReadLine();

                    Console.Write($"Ingrese el puesto del empleado {i + 1}: ");
                    puestos[i] = Console.ReadLine();
                }
                Console.WriteLine("Información agregada correctamente.");
            }


            void VisualizarArreglo()
            {
                Console.Clear();
                Console.WriteLine("== Visualizar información de empleados ==");

                for (int i = 0; i < nombres.Length; i++)
                {
                    Console.WriteLine($"\nEmpleado {i + 1}:");
                    Console.WriteLine($"Nombre: {nombres[i]}");
                    Console.WriteLine($"Edad: {edades[i]}");
                    Console.WriteLine($"Salario: {salarios[i]} Lps.");
                    Console.WriteLine($"Departamento: {departamentos[i]}");
                    Console.WriteLine($"Rango: {rangos[i]}");
                    Console.WriteLine($"Fecha de Ingreso: {fechasIngreso[i]}");
                    Console.WriteLine($"Puesto: {puestos[i]}");
                }
            }


            void ImprimirPosicionArreglo()
            {
                Console.Clear();
                Console.WriteLine("Imprimir información de un empleado específico: ");

                Console.Write("Ingrese la posición del empleado (1-5): ");
                if (int.TryParse(Console.ReadLine(), out int posicion) && posicion > 0 && posicion <= nombres.Length)
                {
                    int index = posicion - 1;
                    Console.WriteLine($"\nEmpleado {posicion}: ");
                    Console.WriteLine($"Nombre: {nombres[index]} ");
                    Console.WriteLine($"Edad: {edades[index]} ");
                    Console.WriteLine($"Salario: {salarios[index]} ");
                    Console.WriteLine($"Departamento: {departamentos[index]} ");
                    Console.WriteLine($"Rango: {rangos[index]} ");
                    Console.WriteLine($"Fecha de Ingreso: {fechasIngreso[index]} ");
                    Console.WriteLine($"Puesto: {puestos[index]} ");
                }
                else
                {
                    Console.WriteLine("Posición no valida. ");
                }
            }

            static void CalcularSalario()
            {
                Console.Clear();
                Console.WriteLine(" Calcular salario mensual y anual de un empleado: ");

                Console.Write("Ingrese el salario base por dia del empleado: ");
                if (double.TryParse(Console.ReadLine(), out double salarioDiario) && salarioDiario > 0)
                {
                    double salarioMensual = CalcularSalarioMensual(salarioDiario);
                    double salarioAnual = CalcularSalarioAnual(salarioMensual);

                    Console.WriteLine($"El salario mensual del empleado es: {salarioMensual} ");
                    Console.WriteLine($"El salario anual del empleado es: {salarioAnual} ");
                }
                else
                {
                    Console.WriteLine("Entrada no válida. Debes ingresar un número positivo para el salario. ");
                }
            }

            static double CalcularSalarioMensual(double salarioDiario)
            {
                int diasLaboralesPorMes = 22; 
                return salarioDiario * diasLaboralesPorMes;
            }

            static double CalcularSalarioAnual(double salarioMensual)
            {
                return salarioMensual * 12;
            }
            Console.ReadLine();
            // Programa no corre debido al modificador static no valido.
        }
    }
}